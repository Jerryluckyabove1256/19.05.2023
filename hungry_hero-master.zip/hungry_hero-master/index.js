const server = require('./lib/server');

server.start();